// JavaScript para o Sistema de Esquadrias

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar tooltips do Bootstrap
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Inicializar popovers do Bootstrap
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Auto-hide alerts após 5 segundos
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);

    // Validação de formulários
    var forms = document.querySelectorAll('.needs-validation');
    Array.prototype.slice.call(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // Confirmação para ações importantes
    var deleteButtons = document.querySelectorAll('.btn-delete');
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            if (!confirm('Tem certeza que deseja excluir este item?')) {
                e.preventDefault();
            }
        });
    });

    // Máscara para campos de data
    var dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(function(input) {
        input.addEventListener('change', function() {
            if (this.value) {
                this.classList.add('has-value');
            } else {
                this.classList.remove('has-value');
            }
        });
    });

    // Máscara para campos de preço
    var priceInputs = document.querySelectorAll('input[name="preco_unitario"]');
    priceInputs.forEach(function(input) {
        input.addEventListener('input', function() {
            var value = this.value.replace(/\D/g, '');
            if (value) {
                value = (parseInt(value) / 100).toFixed(2);
                this.value = value;
            }
        });
    });

    // Auto-complete para campos de dimensões
    var dimensoesInput = document.getElementById('dimensoes');
    if (dimensoesInput) {
        dimensoesInput.addEventListener('input', function() {
            var value = this.value;
            // Adicionar " x " automaticamente se o usuário digitar apenas números
            if (/^\d+$/.test(value) && value.length >= 2) {
                this.value = value + ' x ';
            }
        });
    }

    // Filtro de tabelas
    var searchInputs = document.querySelectorAll('.table-search');
    searchInputs.forEach(function(input) {
        input.addEventListener('keyup', function() {
            var filter = this.value.toLowerCase();
            var table = this.closest('.card').querySelector('table');
            var rows = table.querySelectorAll('tbody tr');
            
            rows.forEach(function(row) {
                var text = row.textContent.toLowerCase();
                if (text.indexOf(filter) > -1) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    });

    // Contador de caracteres para textareas
    var textareas = document.querySelectorAll('textarea[maxlength]');
    textareas.forEach(function(textarea) {
        var maxLength = textarea.getAttribute('maxlength');
        var counter = document.createElement('small');
        counter.className = 'text-muted character-counter';
        counter.textContent = '0 / ' + maxLength;
        
        textarea.parentNode.appendChild(counter);
        
        textarea.addEventListener('input', function() {
            var currentLength = this.value.length;
            counter.textContent = currentLength + ' / ' + maxLength;
            
            if (currentLength > maxLength * 0.9) {
                counter.className = 'text-warning character-counter';
            } else if (currentLength > maxLength) {
                counter.className = 'text-danger character-counter';
            } else {
                counter.className = 'text-muted character-counter';
            }
        });
    });

    // Animações de entrada
    var animatedElements = document.querySelectorAll('.fade-in');
    var observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    });

    animatedElements.forEach(function(element) {
        element.style.opacity = '0';
        element.style.transform = 'translateY(20px)';
        element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(element);
    });

    // Sidebar responsiva
    var sidebarToggle = document.querySelector('.sidebar-toggle');
    var sidebar = document.querySelector('.sidebar');
    
    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('show');
        });
    }

    // Fechar sidebar ao clicar fora (mobile)
    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 768) {
            if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                sidebar.classList.remove('show');
            }
        }
    });

    // Atualizar status de estoque em tempo real
    var estoqueInputs = document.querySelectorAll('input[name="quantidade_estoque"], input[name="quantidade_minima"]');
    estoqueInputs.forEach(function(input) {
        input.addEventListener('input', function() {
            var row = this.closest('tr');
            var estoqueInput = row.querySelector('input[name="quantidade_estoque"]');
            var minimoInput = row.querySelector('input[name="quantidade_minima"]');
            var statusBadge = row.querySelector('.badge');
            
            if (estoqueInput && minimoInput && statusBadge) {
                var estoque = parseInt(estoqueInput.value) || 0;
                var minimo = parseInt(minimoInput.value) || 0;
                
                if (estoque <= minimo) {
                    statusBadge.className = 'badge bg-danger';
                    statusBadge.textContent = 'Estoque Baixo';
                } else if (estoque <= minimo * 1.5) {
                    statusBadge.className = 'badge bg-warning';
                    statusBadge.textContent = 'Atenção';
                } else {
                    statusBadge.className = 'badge bg-success';
                    statusBadge.textContent = 'Normal';
                }
            }
        });
    });

    // Exportar dados para Excel (funcionalidade futura)
    var exportButtons = document.querySelectorAll('.btn-export');
    exportButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            // Implementar exportação para Excel
            alert('Funcionalidade de exportação será implementada em breve!');
        });
    });

    // Notificações toast (funcionalidade futura)
    function showToast(message, type = 'info') {
        // Implementar notificações toast
        console.log('Toast:', message, type);
    }

    // Função para formatar números
    function formatNumber(num) {
        return new Intl.NumberFormat('pt-BR').format(num);
    }

    // Função para formatar moeda
    function formatCurrency(num) {
        return new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        }).format(num);
    }

    // Aplicar formatação em campos de preço
    var priceFields = document.querySelectorAll('.price-field');
    priceFields.forEach(function(field) {
        field.addEventListener('blur', function() {
            var value = parseFloat(this.value);
            if (!isNaN(value)) {
                this.value = formatCurrency(value);
            }
        });
    });

    console.log('Sistema de Esquadrias carregado com sucesso!');
});
