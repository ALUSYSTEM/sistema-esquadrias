// Sistema alternativo usando LocalStorage (funciona offline)
class LocalStorageManager {
    constructor() {
        this.prefix = 'sistema_esquadrias_';
    }

    // Simular autenticação local
    login(email, password) {
        const users = this.getData('usuarios') || [];
        const user = users.find(u => u.email === email && u.password === password);
        
        if (user) {
            localStorage.setItem(this.prefix + 'current_user', JSON.stringify(user));
            return { success: true, user };
        }
        return { success: false, error: 'Usuário ou senha inválidos' };
    }

    logout() {
        localStorage.removeItem(this.prefix + 'current_user');
    }

    getCurrentUser() {
        const userStr = localStorage.getItem(this.prefix + 'current_user');
        return userStr ? JSON.parse(userStr) : null;
    }

    // CRUD para diferentes entidades
    getData(type) {
        const data = localStorage.getItem(this.prefix + type);
        return data ? JSON.parse(data) : [];
    }

    setData(type, data) {
        localStorage.setItem(this.prefix + type, JSON.stringify(data));
    }

    addData(type, item) {
        const data = this.getData(type);
        item.id = Date.now().toString();
        item.created_at = new Date().toISOString();
        data.push(item);
        this.setData(type, data);
        return item;
    }

    updateData(type, id, updates) {
        const data = this.getData(type);
        const index = data.findIndex(item => item.id === id);
        if (index !== -1) {
            data[index] = { ...data[index], ...updates, updated_at: new Date().toISOString() };
            this.setData(type, data);
            return data[index];
        }
        return null;
    }

    deleteData(type, id) {
        const data = this.getData(type);
        const filtered = data.filter(item => item.id !== id);
        this.setData(type, filtered);
        return filtered.length !== data.length;
    }

    // Inicializar dados de exemplo
    initSampleData() {
        // Usuário padrão
        const users = this.getData('usuarios');
        if (users.length === 0) {
            this.setData('usuarios', [
                {
                    id: '1',
                    email: 'admin@sistema.com',
                    password: 'admin123',
                    nome: 'Administrador',
                    role: 'admin',
                    created_at: new Date().toISOString()
                }
            ]);
        }

        // Materiais de exemplo
        const materiais = this.getData('materiais');
        if (materiais.length === 0) {
            this.setData('materiais', [
                {
                    id: '1',
                    nome: 'Plástico Filme',
                    tipo: 'Plástico Filme',
                    quantidade_estoque: 50,
                    quantidade_minima: 10,
                    unidade: 'rolo',
                    preco_unitario: 15.50,
                    fornecedor: 'Fornecedor A',
                    status_alerta: 'normal',
                    created_at: new Date().toISOString()
                },
                {
                    id: '2',
                    nome: 'Plástico Bolha',
                    tipo: 'Plástico Bolha',
                    quantidade_estoque: 5,
                    quantidade_minima: 15,
                    unidade: 'rolo',
                    preco_unitario: 25.00,
                    fornecedor: 'Fornecedor B',
                    status_alerta: 'critico',
                    created_at: new Date().toISOString()
                }
            ]);
        }

        // Obras de exemplo
        const obras = this.getData('obras');
        if (obras.length === 0) {
            this.setData('obras', [
                {
                    id: '1',
                    nome: 'Edifício Residencial Alpha',
                    endereco: 'Rua das Flores, 123',
                    cliente: 'Construtora ABC',
                    data_inicio: new Date().toISOString(),
                    data_prevista: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
                    status: 'Em Andamento',
                    created_at: new Date().toISOString()
                }
            ]);
        }
    }
}

// Tornar disponível globalmente
window.localStorageManager = new LocalStorageManager();
window.localStorageManager.initSampleData();
