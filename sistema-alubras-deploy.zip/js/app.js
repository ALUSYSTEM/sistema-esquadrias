// Sistema de Esquadrias - ALUBRAS
// Aplicação principal em JavaScript com Firebase

class SistemaEsquadrias {
    constructor() {
        this.currentUser = null;
        this.currentPage = 'login';
        this.realtimeListeners = new Map();
        
        this.init();
    }

    async init() {
        // Aguardar Firebase carregar (timeout após 5 segundos se não estiver disponível)
        try {
            await Promise.race([
                this.waitForFirebase(),
                new Promise(resolve => setTimeout(resolve, 5000))
            ]);
        } catch (error) {
            console.log('Firebase não disponível, usando sistema local');
        }
        
        // Configurar autenticação
        this.setupAuth();
        
        // Configurar navegação
        this.setupNavigation();
        
        // Configurar formulários
        this.setupForms();
        
        // Configurar relógio
        this.setupClock();
        
        console.log('Sistema inicializado com sucesso!');
    }

    async waitForFirebase() {
        return new Promise((resolve) => {
            if (window.firebase) {
                resolve();
            } else {
                window.addEventListener('firebaseReady', resolve, { once: true });
            }
        });
    }

    setupAuth() {
        if (window.firebase) {
            // Usar Firebase se disponível
            const { onAuthStateChanged, signInWithEmailAndPassword, signOut, auth } = window.firebase;
            
            onAuthStateChanged(auth, (user) => {
                if (user) {
                    this.currentUser = user;
                    this.showPage('dashboard');
                    this.updateUserInfo();
                    this.startRealtimeUpdates();
                } else {
                    this.currentUser = null;
                    this.showPage('login');
                    this.stopRealtimeUpdates();
                }
            });
        } else {
            // Usar sistema local como fallback
            const currentUser = window.localStorageManager?.getCurrentUser();
            if (currentUser) {
                this.currentUser = currentUser;
                this.showPage('dashboard');
                this.updateUserInfo();
                this.startRealtimeUpdates();
            } else {
                this.currentUser = null;
                this.showPage('login');
                this.stopRealtimeUpdates();
            }
            console.log('Firebase não disponível, usando sistema local');
        }
    }

    setupNavigation() {
        document.querySelectorAll('[data-page]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = e.target.getAttribute('data-page') || 
                           e.target.closest('[data-page]').getAttribute('data-page');
                this.showPage(page);
            });
        });
    }

    setupForms() {
        // Formulário de login
        document.getElementById('login-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleLogin();
        });
    }

    setupClock() {
        const updateTime = () => {
            const now = new Date();
            const timeString = now.toLocaleString('pt-BR');
            const timeElement = document.getElementById('current-time');
            if (timeElement) {
                timeElement.textContent = timeString;
            }
        };
        
        updateTime();
        setInterval(updateTime, 1000);
    }

    async handleLogin() {
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        try {
            this.showLoading('Entrando...');
            
            if (window.firebase) {
                // Usar Firebase se disponível
                const { signInWithEmailAndPassword, auth } = window.firebase;
                await signInWithEmailAndPassword(auth, email, password);
            } else {
                // Usar sistema local como fallback
                const result = window.localStorageManager.login(email, password);
                if (!result.success) {
                    throw new Error(result.error);
                }
                this.currentUser = result.user;
                this.showPage('dashboard');
                this.updateUserInfo();
                this.startRealtimeUpdates();
            }
            
            this.showAlert('Login realizado com sucesso!', 'success');
        } catch (error) {
            let errorMessage = error.message;
            
            // Mensagem mais clara para erro de API key
            if (error.message.includes('api-key-not-valid')) {
                errorMessage = 'API Key do Firebase inválida. Usando sistema local...';
                // Tentar login local automaticamente
                setTimeout(() => {
                    this.showAlert('Tentando login com sistema local...', 'info');
                    const localResult = window.localStorageManager?.login(email, password);
                    if (localResult && localResult.success) {
                        this.currentUser = localResult.user;
                        this.showPage('dashboard');
                        this.updateUserInfo();
                        this.startRealtimeUpdates();
                        this.showAlert('Login local realizado com sucesso!', 'success');
                    }
                }, 1000);
            }
            
            this.showAlert('Erro no login: ' + errorMessage, 'danger');
        } finally {
            this.hideLoading();
        }
    }

    async logout() {
        try {
            if (window.firebase) {
                // Usar Firebase se disponível
                const { signOut, auth } = window.firebase;
                await signOut(auth);
            } else {
                // Usar sistema local como fallback
                window.localStorageManager.logout();
                this.currentUser = null;
                this.showPage('login');
                this.stopRealtimeUpdates();
            }
            this.showAlert('Logout realizado com sucesso!', 'info');
        } catch (error) {
            this.showAlert('Erro no logout: ' + error.message, 'danger');
        }
    }

    showPage(pageName) {
        // Esconder todas as páginas
        document.querySelectorAll('.page-content, .auth-page').forEach(page => {
            page.style.display = 'none';
        });

        // Mostrar página selecionada
        const targetPage = document.getElementById(pageName + '-page');
        if (targetPage) {
            targetPage.style.display = 'block';
            this.currentPage = pageName;
            
            // Carregar conteúdo específico da página
            this.loadPageContent(pageName);
            
            // Atualizar navegação ativa
            this.updateActiveNav(pageName);
        }
    }

    async loadPageContent(pageName) {
        switch (pageName) {
            case 'dashboard':
                await this.loadDashboard();
                break;
            case 'materiais':
                await this.loadMateriais();
                break;
            case 'obras':
                await this.loadObras();
                break;
            case 'esquadrias':
                await this.loadEsquadrias();
                break;
            case 'manutencao':
                await this.loadManutencao();
                break;
            case 'entregas':
                await this.loadEntregas();
                break;
        }
    }

    async loadDashboard() {
        // Carregar estatísticas em tempo real
        await Promise.all([
            this.loadStats(),
            this.loadAlertasEstoque(),
            this.loadObrasRecentes(),
            this.loadMovimentacoesRecentes()
        ]);
    }

    async loadStats() {
        try {
            if (window.firebase) {
                // Usar Firebase se disponível
                const { collection, getDocs, db } = window.firebase;
                
                // Contar obras
                const obrasSnapshot = await getDocs(collection(db, 'obras'));
                const totalObrasEl = document.getElementById('total-obras');
                if (totalObrasEl) totalObrasEl.textContent = obrasSnapshot.size;

                // Contar esquadrias
                const esquadriasSnapshot = await getDocs(collection(db, 'esquadrias'));
                const totalEsquadriasEl = document.getElementById('total-esquadrias');
                if (totalEsquadriasEl) totalEsquadriasEl.textContent = esquadriasSnapshot.size;

                // Contar materiais e alertas
                const materiaisSnapshot = await getDocs(collection(db, 'materiais'));
                const totalMateriaisEl = document.getElementById('total-materiais');
                if (totalMateriaisEl) totalMateriaisEl.textContent = materiaisSnapshot.size;

                let alertas = 0;
                materiaisSnapshot.forEach(doc => {
                    const data = doc.data();
                    if (data.status_alerta === 'critico' || data.status_alerta === 'atencao') {
                        alertas++;
                    }
                });
                const alertasEl = document.getElementById('alertas-estoque');
                if (alertasEl) alertasEl.textContent = alertas;
                
            } else {
                // Usar sistema local como fallback
                const obras = window.localStorageManager?.getData('obras') || [];
                const esquadrias = window.localStorageManager?.getData('esquadrias') || [];
                const materiais = window.localStorageManager?.getData('materiais') || [];
                
                const totalObrasEl = document.getElementById('total-obras');
                const totalEsquadriasEl = document.getElementById('total-esquadrias');
                const totalMateriaisEl = document.getElementById('total-materiais');
                const alertasEl = document.getElementById('alertas-estoque');
                
                if (totalObrasEl) totalObrasEl.textContent = obras.length;
                if (totalEsquadriasEl) totalEsquadriasEl.textContent = esquadrias.length;
                if (totalMateriaisEl) totalMateriaisEl.textContent = materiais.length;
                
                let alertas = 0;
                materiais.forEach(material => {
                    if (material.status_alerta === 'critico' || material.status_alerta === 'atencao') {
                        alertas++;
                    }
                });
                if (alertasEl) alertasEl.textContent = alertas;
            }

        } catch (error) {
            console.error('Erro ao carregar estatísticas:', error);
        }
    }

    async loadAlertasEstoque() {
        const container = document.getElementById('alertas-container');
        if (!container) return;
        
        try {
            let materiais = [];
            
            if (window.firebase) {
                // Usar Firebase se disponível
                const { collection, query, where, getDocs, db } = window.firebase;
                const materiaisSnapshot = await getDocs(
                    query(collection(db, 'materiais'), 
                          where('status_alerta', 'in', ['critico', 'atencao']))
                );
                materiais = materiaisSnapshot.docs.map(doc => doc.data());
            } else {
                // Usar sistema local
                const todosMateriais = window.localStorageManager?.getData('materiais') || [];
                materiais = todosMateriais.filter(m => 
                    m.status_alerta === 'critico' || m.status_alerta === 'atencao'
                );
            }

            if (materiais.length === 0) {
                container.innerHTML = '';
                return;
            }

            let alertasHTML = '<div class="alert alert-warning"><strong>⚠️ Atenção ao Estoque!</strong><ul class="mb-0 mt-2">';
            
            materiais.forEach(material => {
                const classe = material.status_alerta === 'critico' ? 'text-danger' : 'text-warning';
                alertasHTML += `<li class="${classe}">${material.nome} - ${material.quantidade_estoque} ${material.unidade}</li>`;
            });
            
            alertasHTML += '</ul></div>';
            container.innerHTML = alertasHTML;

        } catch (error) {
            console.error('Erro ao carregar alertas:', error);
        }
    }

    async loadMateriais() {
        const pageContent = document.getElementById('materiais-page');
        
        if (!pageContent.innerHTML) {
            pageContent.innerHTML = await this.loadMateriaisTemplate();
        }

        // Configurar listener em tempo real
        this.setupMateriaisRealtime();
    }

    async loadMateriaisTemplate() {
        return `
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-boxes"></i> Materiais de Embalagem</h2>
                <button class="btn btn-primary" onclick="sistema.showNovoMaterialModal()">
                    <i class="fas fa-plus"></i> Novo Material
                </button>
            </div>

            <div class="mb-3">
                <div class="row g-3">
                    <div class="col-md-4">
                        <input type="text" class="form-control" id="pesquisa-materiais" placeholder="Pesquisar materiais...">
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" id="filtro-status">
                            <option value="">Todos os status</option>
                            <option value="normal">Normal</option>
                            <option value="atencao">Atenção</option>
                            <option value="critico">Crítico</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" id="filtro-tipo">
                            <option value="">Todos os tipos</option>
                            <option value="Plástico Filme">Plástico Filme</option>
                            <option value="Plástico Bolha">Plástico Bolha</option>
                            <option value="Papelão">Papelão</option>
                            <option value="Fitilho">Fitilho</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="tabela-materiais">
                            <thead>
                                <tr>
                                    <th>Material</th>
                                    <th>Tipo</th>
                                    <th>Estoque</th>
                                    <th>Mínimo</th>
                                    <th>Preço</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody id="tabela-materiais-body">
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">
                                        <i class="fas fa-spinner fa-spin"></i> Carregando materiais...
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    }

    async setupMateriaisRealtime() {
        if (window.firebase) {
            // Usar Firebase se disponível
            const { collection, query, orderBy, onSnapshot, db } = window.firebase;
            
            const unsubscribe = onSnapshot(
                query(collection(db, 'materiais'), orderBy('created_at', 'desc')),
                (snapshot) => {
                    this.updateMateriaisTable(snapshot);
                },
                (error) => {
                    console.error('Erro no listener de materiais:', error);
                }
            );

            this.realtimeListeners.set('materiais', unsubscribe);
        } else {
            // Usar sistema local - carregar dados imediatamente
            this.updateMateriaisTableLocal();
        }
    }

    updateMateriaisTable(snapshot) {
        const tbody = document.getElementById('tabela-materiais-body');
        if (!tbody) return;

        if (snapshot && snapshot.empty) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center text-muted py-4">
                        <i class="fas fa-inbox"></i><br>Nenhum material cadastrado
                    </td>
                </tr>
            `;
            return;
        }

        let html = '';
        if (snapshot && snapshot.forEach) {
            // Firebase snapshot
            snapshot.forEach(doc => {
                const material = doc.data();
                html += this.createMaterialRow(material, doc.id);
            });
        } else {
            // Dados locais (array de materiais)
            const materiais = Array.isArray(snapshot) ? snapshot : [];
            if (materiais.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">
                            <i class="fas fa-inbox"></i><br>Nenhum material cadastrado
                        </td>
                    </tr>
                `;
                this.setupMateriaisFilters();
                return;
            }
            
            materiais.forEach(material => {
                html += this.createMaterialRow(material, material.id);
            });
        }

        tbody.innerHTML = html;
        this.setupMateriaisFilters();
    }

    updateMateriaisTableLocal() {
        const materiais = window.localStorageManager?.getData('materiais') || [];
        this.updateMateriaisTable(materiais);
    }

    createMaterialRow(material, id) {
        const statusClass = this.getStatusClass(material.status_alerta);
        const statusText = this.getStatusText(material.status_alerta);
        
        return `
            <tr data-status="${material.status_alerta}" data-tipo="${material.tipo}" data-nome="${material.nome.toLowerCase()}">
                <td>
                    <strong>${material.nome}</strong>
                    ${material.especificacoes ? `<br><small class="text-muted">${material.especificacoes}</small>` : ''}
                </td>
                <td><span class="badge bg-info">${material.tipo}</span></td>
                <td><span class="fw-bold ${statusClass}">${material.quantidade_estoque}</span></td>
                <td>${material.quantidade_minima}</td>
                <td>R$ ${(material.preco_unitario || 0).toFixed(2)}</td>
                <td>
                    <span class="badge ${this.getStatusBadgeClass(material.status_alerta)}">
                        <i class="fas ${this.getStatusIcon(material.status_alerta)}"></i>
                        ${statusText}
                    </span>
                </td>
                <td>
                    <div class="btn-group">
                        <button class="btn btn-sm btn-outline-primary" onclick="sistema.showMovimentacaoModal('${id}')" title="Movimentação">
                            <i class="fas fa-exchange-alt"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-warning" onclick="sistema.showEditarMaterialModal('${id}')" title="Editar">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger" onclick="sistema.excluirMaterial('${id}')" title="Excluir">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }

    getStatusClass(status) {
        // Para alertas de estoque
        switch (status) {
            case 'critico': return 'text-danger';
            case 'atencao': return 'text-warning';
            default: return 'text-success';
        }
    }

    getBadgeStatusClass(status) {
        // Para badges de status geral
        switch (status) {
            case 'Em Andamento': return 'bg-primary';
            case 'Concluída': return 'bg-success';
            case 'Pausada': return 'bg-warning';
            case 'critico': return 'bg-danger';
            case 'atencao': return 'bg-warning';
            default: return 'bg-secondary';
        }
    }

    getStatusText(status) {
        switch (status) {
            case 'critico': return 'Crítico';
            case 'atencao': return 'Atenção';
            default: return 'Normal';
        }
    }

    getStatusBadgeClass(status) {
        switch (status) {
            case 'critico': return 'bg-danger';
            case 'atencao': return 'bg-warning';
            default: return 'bg-success';
        }
    }

    getStatusIcon(status) {
        switch (status) {
            case 'critico': return 'fa-exclamation-triangle';
            case 'atencao': return 'fa-exclamation-circle';
            default: return 'fa-check-circle';
        }
    }

    setupMateriaisFilters() {
        const pesquisa = document.getElementById('pesquisa-materiais');
        const filtroStatus = document.getElementById('filtro-status');
        const filtroTipo = document.getElementById('filtro-tipo');

        if (pesquisa) {
            pesquisa.addEventListener('input', () => this.filtrarMateriais());
        }
        if (filtroStatus) {
            filtroStatus.addEventListener('change', () => this.filtrarMateriais());
        }
        if (filtroTipo) {
            filtroTipo.addEventListener('change', () => this.filtrarMateriais());
        }
    }

    filtrarMateriais() {
        const pesquisa = document.getElementById('pesquisa-materiais')?.value.toLowerCase() || '';
        const status = document.getElementById('filtro-status')?.value || '';
        const tipo = document.getElementById('filtro-tipo')?.value || '';

        const rows = document.querySelectorAll('#tabela-materiais tbody tr');
        rows.forEach(row => {
            const nome = row.getAttribute('data-nome') || '';
            const rowStatus = row.getAttribute('data-status') || '';
            const rowTipo = row.getAttribute('data-tipo') || '';

            const matchPesquisa = nome.includes(pesquisa);
            const matchStatus = !status || rowStatus === status;
            const matchTipo = !tipo || rowTipo === tipo;

            row.style.display = (matchPesquisa && matchStatus && matchTipo) ? '' : 'none';
        });
    }

    showAlert(message, type = 'info') {
        const container = document.getElementById('alert-container');
        const alertId = 'alert-' + Date.now();
        
        const alertHTML = `
            <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show" role="alert">
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
        
        container.insertAdjacentHTML('beforeend', alertHTML);
        
        // Auto-remover após 5 segundos
        setTimeout(() => {
            const alertElement = document.getElementById(alertId);
            if (alertElement) {
                alertElement.remove();
            }
        }, 5000);
    }

    showLoading(message = 'Carregando...') {
        // Implementar loading
    }

    hideLoading() {
        // Implementar hide loading
    }

    // Sistema de Modais
    showModal(modalId, title, content) {
        // Remover modal existente se houver
        const existingModal = document.getElementById(modalId);
        if (existingModal) {
            existingModal.remove();
        }

        const modalHTML = `
            <div class="modal fade" id="${modalId}" tabindex="-1" aria-labelledby="${modalId}Label" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="${modalId}Label">${title}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            ${content}
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHTML);

        // Adicionar listeners para o formulário se houver
        const modalElement = document.getElementById(modalId);
        const form = modalElement.querySelector('form');
        if (form) {
            form.addEventListener('submit', (e) => this.handleFormSubmit(e, modalId));
        }

        // Carregar dados específicos do modal se necessário
        this.loadModalData(modalId, modalElement);

        // Mostrar modal
        if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
            const modal = new bootstrap.Modal(modalElement);
            modal.show();
        } else {
            // Fallback caso Bootstrap não esteja disponível
            modalElement.style.display = 'block';
            modalElement.classList.add('show');
            document.body.classList.add('modal-open');
            
            // Criar backdrop manualmente se necessário
            const backdrop = document.createElement('div');
            backdrop.className = 'modal-backdrop fade show';
            document.body.appendChild(backdrop);
        }

        // Limpar modal quando fechado
        modalElement.addEventListener('hidden.bs.modal', () => {
            modalElement.remove();
        });
    }

    closeModal(modalId) {
        const modalElement = document.getElementById(modalId);
        if (modalElement) {
            if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
                const modal = bootstrap.Modal.getInstance(modalElement);
                if (modal) {
                    modal.hide();
                }
            } else {
                // Fallback manual
                modalElement.style.display = 'none';
                modalElement.classList.remove('show');
                document.body.classList.remove('modal-open');
                
                // Remover backdrop
                const backdrop = document.querySelector('.modal-backdrop');
                if (backdrop) {
                    backdrop.remove();
                }
            }
        }
    }

    async loadModalData(modalId, modalElement) {
        try {
            if (modalId === 'nova-esquadria' || modalId === 'nova-entrega') {
                await this.loadObrasParaSelect(modalElement);
            }
        } catch (error) {
            console.error('Erro ao carregar dados do modal:', error);
        }
    }

    async loadObrasParaSelect(modalElement) {
        try {
            let obras = [];
            
            if (window.firebase) {
                const { collection, getDocs, db } = window.firebase;
                const snapshot = await getDocs(collection(db, 'obras'));
                obras = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            } else {
                obras = window.localStorageManager?.getData('obras') || [];
            }

            // Encontrar os selects de obra no modal
            const obraSelects = modalElement.querySelectorAll('select[id*="obra-"]');
            
            obraSelects.forEach(select => {
                // Limpar opções existentes (exceto a primeira)
                while (select.children.length > 1) {
                    select.removeChild(select.lastChild);
                }

                // Adicionar obras
                obras.forEach(obra => {
                    const option = document.createElement('option');
                    option.value = obra.id;
                    option.textContent = obra.nome + ' - ' + obra.cliente;
                    option.setAttribute('data-nome', obra.nome);
                    select.appendChild(option);
                });

                // Adicionar listener para atualizar o campo hidden com o nome da obra
                select.addEventListener('change', (e) => {
                    const selectedOption = e.target.selectedOptions[0];
                    const hiddenInput = modalElement.querySelector('input[id*="obra-nome"]');
                    if (hiddenInput && selectedOption) {
                        hiddenInput.value = selectedOption.getAttribute('data-nome') || selectedOption.textContent.split(' - ')[0];
                    }
                });
            });
        } catch (error) {
            console.error('Erro ao carregar obras:', error);
        }
    }

    async handleFormSubmit(e, modalId) {
        e.preventDefault();
        const form = e.target;
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        // Capturar dados adicionais especiais para alguns modais
        if (modalId === 'nova-esquadria' || modalId === 'nova-entrega') {
            const obraSelect = form.querySelector('select[id*="obra-"]');
            if (obraSelect && obraSelect.value) {
                const selectedOption = obraSelect.selectedOptions[0];
                if (selectedOption) {
                    data.obra_nome = selectedOption.getAttribute('data-nome') || selectedOption.textContent.split(' - ')[0];
                }
            }
        }

        try {
            switch (modalId) {
                case 'novo-material':
                    await this.salvarMaterial(data);
                    break;
                case 'nova-obra':
                    await this.salvarObra(data);
                    break;
                case 'nova-esquadria':
                    await this.salvarEsquadria(data);
                    break;
                case 'nova-manutencao':
                    await this.salvarManutencao(data);
                    break;
                case 'nova-entrega':
                    await this.salvarEntrega(data);
                    break;
            }
            
            this.closeModal(modalId);
            const entityName = modalId.replace('nova-', '').replace('novo-', '');
            this.showAlert(`${entityName.charAt(0).toUpperCase() + entityName.slice(1)} salvo com sucesso!`, 'success');
            
            // Recarregar a página atual se necessário
            if (this.currentPage === 'obras') {
                this.updateObrasTable();
            } else if (this.currentPage === 'esquadrias') {
                this.updateEsquadriasTable();
            } else if (this.currentPage === 'manutencao') {
                this.updateManutencaoTable();
            } else if (this.currentPage === 'entregas') {
                this.updateEntregasTable();
            }
        } catch (error) {
            this.showAlert('Erro ao salvar: ' + error.message, 'danger');
        }
    }

    updateUserInfo() {
        const userEmail = document.getElementById('user-email');
        if (userEmail && this.currentUser) {
            userEmail.textContent = this.currentUser.email;
        }
    }

    startRealtimeUpdates() {
        // Iniciar listeners em tempo real para todas as páginas
        if (this.currentPage === 'dashboard') {
            this.setupDashboardRealtime();
        }
    }

    stopRealtimeUpdates() {
        // Parar todos os listeners
        this.realtimeListeners.forEach(unsubscribe => unsubscribe());
        this.realtimeListeners.clear();
    }

    updateActiveNav(activePage) {
        document.querySelectorAll('[data-page]').forEach(link => {
            link.closest('.nav-item')?.classList.remove('active');
        });
        
        const activeLink = document.querySelector(`[data-page="${activePage}"]`);
        if (activeLink) {
            activeLink.closest('.nav-item')?.classList.add('active');
        }
    }

    async showNovoMaterialModal() {
        this.showModal('novo-material', 'Novo Material de Embalagem', this.getNovoMaterialModalHTML());
    }

    getNovoMaterialModalHTML() {
        return `
            <form id="form-novo-material">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="nome-material" class="form-label">Nome do Material <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="nome-material" name="nome" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="tipo-material" class="form-label">Tipo de Material <span class="text-danger">*</span></label>
                        <select class="form-select" id="tipo-material" name="tipo" required>
                            <option value="">Selecione o tipo</option>
                            <option value="Plástico Filme">Plástico Filme</option>
                            <option value="Plástico Bolha">Plástico Bolha</option>
                            <option value="Papelão">Papelão</option>
                            <option value="Fitilho">Fitilho</option>
                            <option value="Plástico Termoencolhível (com logo)">Plástico Termoencolhível (com logo)</option>
                            <option value="Plástico Termoencolhível (sem logo)">Plástico Termoencolhível (sem logo)</option>
                            <option value="Etiquetas">Etiquetas</option>
                            <option value="Ribbons">Ribbons</option>
                            <option value="Outros">Outros</option>
                        </select>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="unidade-material" class="form-label">Unidade <span class="text-danger">*</span></label>
                        <select class="form-select" id="unidade-material" name="unidade" required>
                            <option value="un">Unidade</option>
                            <option value="kg">Quilograma</option>
                            <option value="m">Metro</option>
                            <option value="m²">Metro Quadrado</option>
                            <option value="m³">Metro Cúbico</option>
                            <option value="l">Litro</option>
                            <option value="cx">Caixa</option>
                            <option value="rolo">Rolo</option>
                            <option value="pct">Pacote</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="especificacoes-material" class="form-label">Especificações</label>
                        <input type="text" class="form-control" id="especificacoes-material" name="especificacoes" placeholder="Ex: Tamanho, cor, espessura...">
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="descricao-material" class="form-label">Descrição</label>
                    <textarea class="form-control" id="descricao-material" name="descricao" rows="3" placeholder="Descrição detalhada do material..."></textarea>
                </div>
                
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label for="quantidade-estoque-material" class="form-label">Quantidade em Estoque <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="quantidade-estoque-material" name="quantidade_estoque" min="0" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="quantidade-minima-material" class="form-label">Quantidade Mínima <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="quantidade-minima-material" name="quantidade_minima" min="1" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="preco-unitario-material" class="form-label">Preço Unitário (R$)</label>
                        <input type="number" class="form-control" id="preco-unitario-material" name="preco_unitario" min="0" step="0.01">
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="fornecedor-material" class="form-label">Fornecedor</label>
                    <input type="text" class="form-control" id="fornecedor-material" name="fornecedor" placeholder="Nome do fornecedor...">
                </div>
                
                <div class="d-flex justify-content-end">
                    <button type="button" class="btn btn-secondary me-2" onclick="sistema.closeModal('novo-material')">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Salvar Material
                    </button>
                </div>
            </form>
        `;
    }

    async showEditarMaterialModal(materialId) {
        // Implementar modal para editar material
        this.showAlert('Funcionalidade em desenvolvimento', 'info');
    }

    async showMovimentacaoModal(materialId) {
        // Implementar modal para movimentação
        this.showAlert('Funcionalidade em desenvolvimento', 'info');
    }

    async excluirMaterial(materialId) {
        if (confirm('Tem certeza que deseja excluir este material?')) {
            try {
                if (window.firebase) {
                    const { doc, deleteDoc, db } = window.firebase;
                    await deleteDoc(doc(db, 'materiais', materialId));
                } else {
                    // Usar sistema local
                    window.localStorageManager.deleteData('materiais', materialId);
                }
                this.showAlert('Material excluído com sucesso!', 'success');
                // Recarregar tabela de materiais se estiver na página
                if (this.currentPage === 'materiais') {
                    this.loadMateriais();
                }
            } catch (error) {
                this.showAlert('Erro ao excluir material: ' + error.message, 'danger');
            }
        }
    }

    // ==================== MÉTODOS FALTANTES ====================
    
    async loadObras() {
        const pageContent = document.getElementById('obras-page');
        
        if (!pageContent.innerHTML) {
            pageContent.innerHTML = await this.loadObrasTemplate();
        }
        
        // Carregar dados das obras
        await this.updateObrasTable();
    }

    async loadObrasTemplate() {
        return `
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-building"></i> Obras</h2>
                <button class="btn btn-primary" onclick="sistema.showNovaObraModal()">
                    <i class="fas fa-plus"></i> Nova Obra
                </button>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="tabela-obras">
                            <thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>Cliente</th>
                                    <th>Endereço</th>
                                    <th>Status</th>
                                    <th>Data Início</th>
                                    <th>Data Prevista</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody id="tabela-obras-body">
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">
                                        <i class="fas fa-spinner fa-spin"></i> Carregando obras...
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    }

    async updateObrasTable() {
        const tbody = document.getElementById('tabela-obras-body');
        if (!tbody) return;

        try {
            let obras = [];
            
            if (window.firebase) {
                // Usar Firebase
                const { collection, getDocs, db } = window.firebase;
                const snapshot = await getDocs(collection(db, 'obras'));
                obras = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            } else {
                // Usar sistema local
                obras = window.localStorageManager?.getData('obras') || [];
            }

            if (obras.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">
                            <i class="fas fa-building"></i><br>Nenhuma obra cadastrada
                        </td>
                    </tr>
                `;
                return;
            }

            let html = '';
            obras.forEach(obra => {
                const dataInicio = new Date(obra.data_inicio).toLocaleDateString('pt-BR');
                const dataPrevista = new Date(obra.data_prevista).toLocaleDateString('pt-BR');
                const statusClass = this.getBadgeStatusClass(obra.status);
                
                html += `
                    <tr>
                        <td><strong>${obra.nome}</strong></td>
                        <td>${obra.cliente}</td>
                        <td>${obra.endereco}</td>
                        <td><span class="badge ${statusClass}">${obra.status}</span></td>
                        <td>${dataInicio}</td>
                        <td>${dataPrevista}</td>
                        <td>
                            <div class="btn-group">
                                <button class="btn btn-sm btn-outline-warning" onclick="sistema.showEditarObraModal('${obra.id}')" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger" onclick="sistema.excluirObra('${obra.id}')" title="Excluir">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            });

            tbody.innerHTML = html;
        } catch (error) {
            console.error('Erro ao carregar obras:', error);
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center text-danger py-4">
                        <i class="fas fa-exclamation-triangle"></i><br>Erro ao carregar obras
                    </td>
                </tr>
            `;
        }
    }

    async loadEsquadrias() {
        const pageContent = document.getElementById('esquadrias-page');
        
        if (!pageContent.innerHTML) {
            pageContent.innerHTML = await this.loadEsquadriasTemplate();
        }
        
        await this.updateEsquadriasTable();
    }

    async loadEsquadriasTemplate() {
        return `
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-window-maximize"></i> Esquadrias</h2>
                <button class="btn btn-primary" onclick="sistema.showNovaEsquadriaModal()">
                    <i class="fas fa-plus"></i> Nova Esquadria
                </button>
            </div>

            <div class="mb-3">
                <div class="row g-3">
                    <div class="col-md-6">
                        <select class="form-select" id="filtro-obra-esquadrias">
                            <option value="">Todas as obras</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <input type="text" class="form-control" id="pesquisa-esquadrias" placeholder="Pesquisar esquadrias...">
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="tabela-esquadrias">
                            <thead>
                                <tr>
                                    <th>Obra</th>
                                    <th>Tipo</th>
                                    <th>Dimensões</th>
                                    <th>Material</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody id="tabela-esquadrias-body">
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-4">
                                        <i class="fas fa-spinner fa-spin"></i> Carregando esquadrias...
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    }

    async loadManutencao() {
        const pageContent = document.getElementById('manutencao-page');
        
        if (!pageContent.innerHTML) {
            pageContent.innerHTML = await this.loadManutencaoTemplate();
        }
        
        await this.updateManutencaoTable();
    }

    async loadManutencaoTemplate() {
        return `
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-tools"></i> Manutenção de Caminhões</h2>
                <button class="btn btn-primary" onclick="sistema.showNovaManutencaoModal()">
                    <i class="fas fa-plus"></i> Nova Manutenção
                </button>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="tabela-manutencao">
                            <thead>
                                <tr>
                                    <th>Placa</th>
                                    <th>Data</th>
                                    <th>Tipo</th>
                                    <th>Descrição</th>
                                    <th>Valor</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody id="tabela-manutencao-body">
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-4">
                                        <i class="fas fa-spinner fa-spin"></i> Carregando manutenções...
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    }

    async loadEntregas() {
        const pageContent = document.getElementById('entregas-page');
        
        if (!pageContent.innerHTML) {
            pageContent.innerHTML = await this.loadEntregasTemplate();
        }
        
        await this.updateEntregasTable();
    }

    async loadEntregasTemplate() {
        return `
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-truck"></i> Programação de Entregas</h2>
                <button class="btn btn-primary" onclick="sistema.showNovaEntregaModal()">
                    <i class="fas fa-plus"></i> Nova Programação
                </button>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="tabela-entregas">
                            <thead>
                                <tr>
                                    <th>Número</th>
                                    <th>Obra</th>
                                    <th>Caminhoneiro</th>
                                    <th>Data Carregamento</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody id="tabela-entregas-body">
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-4">
                                        <i class="fas fa-spinner fa-spin"></i> Carregando programações...
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    }

    async loadObrasRecentes() {
        const container = document.getElementById('obras-recentes');
        if (!container) return;

        try {
            let obras = [];
            
            if (window.firebase) {
                const { collection, getDocs, db } = window.firebase;
                const snapshot = await getDocs(collection(db, 'obras'));
                obras = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })).slice(0, 5);
            } else {
                obras = (window.localStorageManager?.getData('obras') || []).slice(0, 5);
            }

            if (obras.length === 0) {
                container.innerHTML = '<p class="text-muted">Nenhuma obra recente</p>';
                return;
            }

            let html = '<ul class="list-unstyled">';
            obras.forEach(obra => {
                const data = new Date(obra.data_inicio).toLocaleDateString('pt-BR');
                html += `
                    <li class="mb-2">
                        <strong>${obra.nome}</strong><br>
                        <small class="text-muted">${obra.cliente} - ${data}</small>
                    </li>
                `;
            });
            html += '</ul>';
            
            container.innerHTML = html;
        } catch (error) {
            console.error('Erro ao carregar obras recentes:', error);
            container.innerHTML = '<p class="text-danger">Erro ao carregar dados</p>';
        }
    }

    async loadMovimentacoesRecentes() {
        const container = document.getElementById('movimentacoes-recentes');
        if (!container) return;

        try {
            let movimentacoes = [];
            
            if (window.firebase) {
                const { collection, getDocs, db } = window.firebase;
                const snapshot = await getDocs(collection(db, 'movimentacoes_estoque'));
                movimentacoes = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })).slice(0, 5);
            } else {
                movimentacoes = (window.localStorageManager?.getData('movimentacoes_estoque') || []).slice(0, 5);
            }

            if (movimentacoes.length === 0) {
                container.innerHTML = '<p class="text-muted">Nenhuma movimentação recente</p>';
                return;
            }

            let html = '<ul class="list-unstyled">';
            movimentacoes.forEach(mov => {
                const data = new Date(mov.created_at).toLocaleDateString('pt-BR');
                const tipo = mov.tipo_movimentacao === 'entrada' ? '📈' : '📉';
                html += `
                    <li class="mb-2">
                        ${tipo} <strong>${mov.quantidade}</strong> un - ${data}
                    </li>
                `;
            });
            html += '</ul>';
            
            container.innerHTML = html;
        } catch (error) {
            console.error('Erro ao carregar movimentações:', error);
            container.innerHTML = '<p class="text-danger">Erro ao carregar dados</p>';
        }
    }


    // Métodos para modais e ações (implementações básicas)

    async showEditarObraModal(obraId) {
        this.showAlert('Modal de editar obra será implementado', 'info');
    }

    async excluirObra(obraId) {
        if (confirm('Tem certeza que deseja excluir esta obra?')) {
            try {
                if (window.firebase) {
                    const { doc, deleteDoc, db } = window.firebase;
                    await deleteDoc(doc(db, 'obras', obraId));
                } else {
                    window.localStorageManager.deleteData('obras', obraId);
                }
                this.showAlert('Obra excluída com sucesso!', 'success');
                this.updateObrasTable();
            } catch (error) {
                this.showAlert('Erro ao excluir obra: ' + error.message, 'danger');
            }
        }
    }

    async updateEsquadriasTable() {
        const tbody = document.getElementById('tabela-esquadrias-body');
        if (!tbody) return;

        try {
            let esquadrias = [];
            
            if (window.firebase) {
                const { collection, getDocs, db } = window.firebase;
                const snapshot = await getDocs(collection(db, 'esquadrias'));
                esquadrias = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            } else {
                esquadrias = window.localStorageManager?.getData('esquadrias') || [];
            }

            if (esquadrias.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            <i class="fas fa-window-maximize"></i><br>Nenhuma esquadria cadastrada
                        </td>
                    </tr>
                `;
                return;
            }

            let html = '';
            esquadrias.forEach(esquadria => {
                html += `
                    <tr>
                        <td>${esquadria.obra_nome || 'N/A'}</td>
                        <td><span class="badge bg-info">${esquadria.tipo}</span></td>
                        <td>${esquadria.largura}x${esquadria.altura} cm</td>
                        <td>${esquadria.material}</td>
                        <td><span class="badge ${this.getBadgeStatusClass(esquadria.status)}">${esquadria.status}</span></td>
                        <td>
                            <div class="btn-group">
                                <button class="btn btn-sm btn-outline-warning" onclick="sistema.showEditarEsquadriaModal('${esquadria.id}')" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger" onclick="sistema.excluirEsquadria('${esquadria.id}')" title="Excluir">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            });

            tbody.innerHTML = html;
        } catch (error) {
            console.error('Erro ao carregar esquadrias:', error);
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center text-danger py-4">
                        <i class="fas fa-exclamation-triangle"></i><br>Erro ao carregar esquadrias
                    </td>
                </tr>
            `;
        }
    }

    async updateManutencaoTable() {
        const tbody = document.getElementById('tabela-manutencao-body');
        if (!tbody) return;

        try {
            let manutencoes = [];
            
            if (window.firebase) {
                const { collection, getDocs, db } = window.firebase;
                const snapshot = await getDocs(collection(db, 'manutencoes'));
                manutencoes = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            } else {
                manutencoes = window.localStorageManager?.getData('manutencoes') || [];
            }

            if (manutencoes.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            <i class="fas fa-tools"></i><br>Nenhuma manutenção registrada
                        </td>
                    </tr>
                `;
                return;
            }

            let html = '';
            manutencoes.forEach(manutencao => {
                const data = new Date(manutencao.data).toLocaleDateString('pt-BR');
                html += `
                    <tr>
                        <td><strong>${manutencao.placa}</strong></td>
                        <td>${data}</td>
                        <td><span class="badge bg-info">${manutencao.tipo}</span></td>
                        <td>${manutencao.descricao}</td>
                        <td>R$ ${(manutencao.valor || 0).toFixed(2)}</td>
                        <td>
                            <div class="btn-group">
                                <button class="btn btn-sm btn-outline-warning" onclick="sistema.showEditarManutencaoModal('${manutencao.id}')" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger" onclick="sistema.excluirManutencao('${manutencao.id}')" title="Excluir">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            });

            tbody.innerHTML = html;
        } catch (error) {
            console.error('Erro ao carregar manutenções:', error);
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center text-danger py-4">
                        <i class="fas fa-exclamation-triangle"></i><br>Erro ao carregar manutenções
                    </td>
                </tr>
            `;
        }
    }

    async updateEntregasTable() {
        const tbody = document.getElementById('tabela-entregas-body');
        if (!tbody) return;

        try {
            let entregas = [];
            
            if (window.firebase) {
                const { collection, getDocs, db } = window.firebase;
                const snapshot = await getDocs(collection(db, 'entregas'));
                entregas = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            } else {
                entregas = window.localStorageManager?.getData('entregas') || [];
            }

            if (entregas.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            <i class="fas fa-truck"></i><br>Nenhuma programação de entrega
                        </td>
                    </tr>
                `;
                return;
            }

            let html = '';
            entregas.forEach(entrega => {
                const data = new Date(entrega.data_carregamento).toLocaleDateString('pt-BR');
                const statusClass = this.getBadgeStatusClass(entrega.status);
                html += `
                    <tr>
                        <td><strong>#${entrega.numero}</strong></td>
                        <td>${entrega.obra_nome}</td>
                        <td>${entrega.caminhoneiro}</td>
                        <td>${data}</td>
                        <td><span class="badge ${statusClass}">${entrega.status}</span></td>
                        <td>
                            <div class="btn-group">
                                <button class="btn btn-sm btn-outline-primary" onclick="sistema.showDetalhesEntregaModal('${entrega.id}')" title="Detalhes">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-warning" onclick="sistema.showEditarEntregaModal('${entrega.id}')" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            });

            tbody.innerHTML = html;
        } catch (error) {
            console.error('Erro ao carregar entregas:', error);
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center text-danger py-4">
                        <i class="fas fa-exclamation-triangle"></i><br>Erro ao carregar entregas
                    </td>
                </tr>
            `;
        }
    }


    // Métodos de exclusão para todas as entidades
    async excluirEsquadria(esquadriaId) {
        if (confirm('Tem certeza que deseja excluir esta esquadria?')) {
            try {
                if (window.firebase) {
                    const { doc, deleteDoc, db } = window.firebase;
                    await deleteDoc(doc(db, 'esquadrias', esquadriaId));
                } else {
                    window.localStorageManager.deleteData('esquadrias', esquadriaId);
                }
                this.showAlert('Esquadria excluída com sucesso!', 'success');
                this.updateEsquadriasTable();
            } catch (error) {
                this.showAlert('Erro ao excluir esquadria: ' + error.message, 'danger');
            }
        }
    }

    async excluirManutencao(manutencaoId) {
        if (confirm('Tem certeza que deseja excluir esta manutenção?')) {
            try {
                if (window.firebase) {
                    const { doc, deleteDoc, db } = window.firebase;
                    await deleteDoc(doc(db, 'manutencoes', manutencaoId));
                } else {
                    window.localStorageManager.deleteData('manutencoes', manutencaoId);
                }
                this.showAlert('Manutenção excluída com sucesso!', 'success');
                this.updateManutencaoTable();
            } catch (error) {
                this.showAlert('Erro ao excluir manutenção: ' + error.message, 'danger');
            }
        }
    }

    // Métodos adicionais necessários nas tabelas
    async showEditarEsquadriaModal(esquadriaId) {
        this.showAlert('Modal de editar esquadria será implementado', 'info');
    }

    async showEditarManutencaoModal(manutencaoId) {
        this.showAlert('Modal de editar manutenção será implementado', 'info');
    }

    async showDetalhesEntregaModal(entregaId) {
        this.showAlert('Modal de detalhes da entrega será implementado', 'info');
    }

    async showEditarEntregaModal(entregaId) {
        this.showAlert('Modal de editar entrega será implementado', 'info');
    }

    // ==================== MÉTODOS DE SALVAR ====================
    
    async salvarMaterial(data) {
        // Validar dados
        if (!data.nome || !data.tipo || !data.quantidade_estoque || !data.quantidade_minima) {
            throw new Error('Preencha todos os campos obrigatórios');
        }

        const material = {
            nome: data.nome,
            tipo: data.tipo,
            descricao: data.descricao || '',
            quantidade_estoque: parseInt(data.quantidade_estoque),
            quantidade_minima: parseInt(data.quantidade_minima),
            unidade: data.unidade || 'un',
            preco_unitario: parseFloat(data.preco_unitario || 0),
            fornecedor: data.fornecedor || '',
            especificacoes: data.especificacoes || '',
            status_alerta: this.calcularStatusAlerta(parseInt(data.quantidade_estoque), parseInt(data.quantidade_minima)),
            created_at: new Date().toISOString()
        };

        if (window.firebase) {
            const { collection, addDoc, db } = window.firebase;
            await addDoc(collection(db, 'materiais'), material);
        } else {
            window.localStorageManager.addData('materiais', material);
        }

        // Recarregar tabela
        this.updateMateriaisTableLocal();
    }

    async salvarObra(data) {
        if (!data.nome || !data.cliente || !data.endereco) {
            throw new Error('Preencha todos os campos obrigatórios');
        }

        const obra = {
            nome: data.nome,
            cliente: data.cliente,
            endereco: data.endereco,
            status: data.status || 'Em Andamento',
            data_inicio: data.data_inicio,
            data_prevista: data.data_prevista,
            descricao: data.descricao || '',
            created_at: new Date().toISOString()
        };

        if (window.firebase) {
            const { collection, addDoc, db } = window.firebase;
            await addDoc(collection(db, 'obras'), obra);
        } else {
            window.localStorageManager.addData('obras', obra);
        }

        this.updateObrasTable();
    }

    async salvarEsquadria(data) {
        if (!data.obra_id || !data.tipo || !data.largura || !data.altura) {
            throw new Error('Preencha todos os campos obrigatórios');
        }

        const esquadria = {
            obra_id: data.obra_id,
            obra_nome: data.obra_nome,
            tipo: data.tipo,
            largura: parseInt(data.largura),
            altura: parseInt(data.altura),
            material: data.material || '',
            status: data.status || 'Em Produção',
            observacoes: data.observacoes || '',
            created_at: new Date().toISOString()
        };

        if (window.firebase) {
            const { collection, addDoc, db } = window.firebase;
            await addDoc(collection(db, 'esquadrias'), esquadria);
        } else {
            window.localStorageManager.addData('esquadrias', esquadria);
        }

        this.updateEsquadriasTable();
    }

    async salvarManutencao(data) {
        if (!data.placa || !data.data || !data.tipo || !data.descricao) {
            throw new Error('Preencha todos os campos obrigatórios');
        }

        const manutencao = {
            placa: data.placa,
            data: data.data,
            tipo: data.tipo,
            descricao: data.descricao,
            valor: parseFloat(data.valor || 0),
            fornecedor: data.fornecedor || '',
            observacoes: data.observacoes || '',
            created_at: new Date().toISOString()
        };

        if (window.firebase) {
            const { collection, addDoc, db } = window.firebase;
            await addDoc(collection(db, 'manutencoes'), manutencao);
        } else {
            window.localStorageManager.addData('manutencoes', manutencao);
        }

        this.updateManutencaoTable();
    }

    async salvarEntrega(data) {
        if (!data.numero || !data.obra_id || !data.caminhoneiro || !data.data_carregamento) {
            throw new Error('Preencha todos os campos obrigatórios');
        }

        const entrega = {
            numero: data.numero,
            obra_id: data.obra_id,
            obra_nome: data.obra_nome,
            caminhoneiro: data.caminhoneiro,
            data_carregamento: data.data_carregamento,
            status: data.status || 'Programada',
            observacoes: data.observacoes || '',
            created_at: new Date().toISOString()
        };

        if (window.firebase) {
            const { collection, addDoc, db } = window.firebase;
            await addDoc(collection(db, 'entregas'), entrega);
        } else {
            window.localStorageManager.addData('entregas', entrega);
        }

        this.updateEntregasTable();
    }

    calcularStatusAlerta(estoque, minimo) {
        if (estoque <= 0) return 'critico';
        if (estoque <= minimo) return 'atencao';
        return 'normal';
    }

    // ==================== MODAIS DE CADASTRO ====================

    async showNovaObraModal() {
        this.showModal('nova-obra', 'Nova Obra', this.getNovaObraModalHTML());
    }

    getNovaObraModalHTML() {
        return `
            <form id="form-nova-obra">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="nome-obra" class="form-label">Nome da Obra <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="nome-obra" name="nome" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="cliente-obra" class="form-label">Cliente <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="cliente-obra" name="cliente" required>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="endereco-obra" class="form-label">Endereço <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="endereco-obra" name="endereco" required>
                </div>
                
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label for="status-obra" class="form-label">Status</label>
                        <select class="form-select" id="status-obra" name="status">
                            <option value="Em Andamento">Em Andamento</option>
                            <option value="Concluída">Concluída</option>
                            <option value="Pausada">Pausada</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="data-inicio-obra" class="form-label">Data de Início</label>
                        <input type="date" class="form-control" id="data-inicio-obra" name="data_inicio">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="data-prevista-obra" class="form-label">Data Prevista</label>
                        <input type="date" class="form-control" id="data-prevista-obra" name="data_prevista">
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="descricao-obra" class="form-label">Descrição</label>
                    <textarea class="form-control" id="descricao-obra" name="descricao" rows="3" placeholder="Descrição detalhada da obra..."></textarea>
                </div>
                
                <div class="d-flex justify-content-end">
                    <button type="button" class="btn btn-secondary me-2" onclick="sistema.closeModal('nova-obra')">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Salvar Obra
                    </button>
                </div>
            </form>
        `;
    }

    async showNovaEsquadriaModal() {
        this.showModal('nova-esquadria', 'Nova Esquadria', this.getNovaEsquadriaModalHTML());
    }

    getNovaEsquadriaModalHTML() {
        return `
            <form id="form-nova-esquadria">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="obra-esquadria" class="form-label">Obra <span class="text-danger">*</span></label>
                        <select class="form-select" id="obra-esquadria" name="obra_id" required>
                            <option value="">Selecione a obra</option>
                        </select>
                        <input type="hidden" id="obra-nome-esquadria" name="obra_nome">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="tipo-esquadria" class="form-label">Tipo <span class="text-danger">*</span></label>
                        <select class="form-select" id="tipo-esquadria" name="tipo" required>
                            <option value="">Selecione o tipo</option>
                            <option value="Janela">Janela</option>
                            <option value="Porta">Porta</option>
                            <option value="Portão">Portão</option>
                            <option value="Guarita">Guarita</option>
                            <option value="Outros">Outros</option>
                        </select>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label for="largura-esquadria" class="form-label">Largura (cm) <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="largura-esquadria" name="largura" min="1" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="altura-esquadria" class="form-label">Altura (cm) <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="altura-esquadria" name="altura" min="1" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="status-esquadria" class="form-label">Status</label>
                        <select class="form-select" id="status-esquadria" name="status">
                            <option value="Em Produção">Em Produção</option>
                            <option value="Pronta">Pronta</option>
                            <option value="Entregue">Entregue</option>
                        </select>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="material-esquadria" class="form-label">Material</label>
                        <select class="form-select" id="material-esquadria" name="material">
                            <option value="">Selecione o material</option>
                            <option value="Alumínio">Alumínio</option>
                            <option value="PVC">PVC</option>
                            <option value="Madeira">Madeira</option>
                            <option value="Aço">Aço</option>
                        </select>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="observacoes-esquadria" class="form-label">Observações</label>
                    <textarea class="form-control" id="observacoes-esquadria" name="observacoes" rows="3" placeholder="Observações sobre a esquadria..."></textarea>
                </div>
                
                <div class="d-flex justify-content-end">
                    <button type="button" class="btn btn-secondary me-2" onclick="sistema.closeModal('nova-esquadria')">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Salvar Esquadria
                    </button>
                </div>
            </form>
        `;
    }

    async showNovaManutencaoModal() {
        this.showModal('nova-manutencao', 'Nova Manutenção', this.getNovaManutencaoModalHTML());
    }

    getNovaManutencaoModalHTML() {
        return `
            <form id="form-nova-manutencao">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="placa-manutencao" class="form-label">Placa do Veículo <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="placa-manutencao" name="placa" required placeholder="ABC-1234">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="data-manutencao" class="form-label">Data <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="data-manutencao" name="data" required>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="tipo-manutencao" class="form-label">Tipo de Manutenção <span class="text-danger">*</span></label>
                        <select class="form-select" id="tipo-manutencao" name="tipo" required>
                            <option value="">Selecione o tipo</option>
                            <option value="Preventiva">Preventiva</option>
                            <option value="Corretiva">Corretiva</option>
                            <option value="Emergencial">Emergencial</option>
                            <option value="Pneumáticos">Pneumáticos</option>
                            <option value="Óleo e Filtros">Óleo e Filtros</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="valor-manutencao" class="form-label">Valor (R$)</label>
                        <input type="number" class="form-control" id="valor-manutencao" name="valor" min="0" step="0.01">
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="descricao-manutencao" class="form-label">Descrição <span class="text-danger">*</span></label>
                    <textarea class="form-control" id="descricao-manutencao" name="descricao" rows="3" required placeholder="Descreva os serviços realizados..."></textarea>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="fornecedor-manutencao" class="form-label">Fornecedor/Serviço</label>
                        <input type="text" class="form-control" id="fornecedor-manutencao" name="fornecedor" placeholder="Nome do fornecedor ou serviço...">
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="observacoes-manutencao" class="form-label">Observações</label>
                    <textarea class="form-control" id="observacoes-manutencao" name="observacoes" rows="2" placeholder="Observações adicionais..."></textarea>
                </div>
                
                <div class="d-flex justify-content-end">
                    <button type="button" class="btn btn-secondary me-2" onclick="sistema.closeModal('nova-manutencao')">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Salvar Manutenção
                    </button>
                </div>
            </form>
        `;
    }

    async showNovaEntregaModal() {
        this.showModal('nova-entrega', 'Nova Programação de Entrega', this.getNovaEntregaModalHTML());
    }

    getNovaEntregaModalHTML() {
        return `
            <form id="form-nova-entrega">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="numero-entrega" class="form-label">Número da Entrega <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="numero-entrega" name="numero" required placeholder="Ex: ENT-001">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="obra-entrega" class="form-label">Obra <span class="text-danger">*</span></label>
                        <select class="form-select" id="obra-entrega" name="obra_id" required>
                            <option value="">Selecione a obra</option>
                        </select>
                        <input type="hidden" id="obra-nome-entrega" name="obra_nome">
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="caminhoneiro-entrega" class="form-label">Caminhoneiro <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="caminhoneiro-entrega" name="caminhoneiro" required placeholder="Nome do caminhoneiro...">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="data-carregamento-entrega" class="form-label">Data do Carregamento <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="data-carregamento-entrega" name="data_carregamento" required>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="status-entrega" class="form-label">Status</label>
                        <select class="form-select" id="status-entrega" name="status">
                            <option value="Programada">Programada</option>
                            <option value="Em Trânsito">Em Trânsito</option>
                            <option value="Entregue">Entregue</option>
                            <option value="Cancelada">Cancelada</option>
                        </select>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="observacoes-entrega" class="form-label">Observações</label>
                    <textarea class="form-control" id="observacoes-entrega" name="observacoes" rows="3" placeholder="Observações sobre a entrega..."></textarea>
                </div>
                
                <div class="d-flex justify-content-end">
                    <button type="button" class="btn btn-secondary me-2" onclick="sistema.closeModal('nova-entrega')">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Salvar Programação
                    </button>
                </div>
            </form>
        `;
    }
}

// Inicializar aplicação quando DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    window.sistema = new SistemaEsquadrias();
    
    // Tornar logout disponível globalmente
    window.logout = () => sistema.logout();
});

// Configurações adicionais do Firebase
window.addEventListener('DOMContentLoaded', () => {
    // Ajustar referências do Firebase
    if (window.firebase) {
        window.sistema.firebase = window.firebase;
    }
});
